//
//  AppDelegate.swift
//  Sam_PlaneGame
//
//  Created by user147336 on 1/11/19.
//  Copyright © 2019 SamKrol. All rights reserved.
//

import UIKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [U: return true])
        }

class ViewController: UIViewController {
    
    @IBOutlet var numberLabel : UILabel?
    @IBOutlet var gameOverView : UIView?
    var countDown : Timer?
    
    var counter : Int = 12 {
        didSet {
            if let numberLabel = numberLabel {
                numberLabel.text = "\(counter)"
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        counter = 12
        countDown = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { aTimer in
            if (0 < self.counter) {
                self.counter -= 1
            } else if let gameOverView = self.gameOverView {
                gameOverView.isHidden = false
            }
        }
    }
    
    @IBAction func increment() {
        if (0 < counter) {
            counter += 1
        }
    }
    
    @IBAction func newGame () {
        counter = 12
        if let gameOverView = gameOverView {
            gameOverView.isHidden = true
        }
    }
    
}

}
