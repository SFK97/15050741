//
//  ViewController.swift
//  Sam_PlaneGameBest
//
//  Created by Sam Krol on 23/06/2019.
//  Copyright © 2019 Sam Krol. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var replayButton: UIImageView!
    @IBOutlet weak var gameOverImage: UIImageView!
    @IBOutlet weak var playButton: UIImageView!
    @IBOutlet weak var scoreLabel: UILabel!
    
    var coinMoving: [UIImageView] = []
    var birdMoving: [UIImageView] = []
    
    var planeMoving: UIImageView!
    var roadMoving: UIImageView!
    var treeMoving: UIImageView!
    
    var animator: UIDynamicAnimator!
    var collisionBehavior: UICollisionBehavior!
    var itemBehavior: UIDynamicItemBehavior!
    
    let mainWidth = UIScreen.main.bounds.size.width
    let mainHeight = UIScreen.main.bounds.size.height
    
    var itemA = DispatchWorkItem {}
    var gameIsPlaying = false
    var score = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        animator = UIDynamicAnimator(referenceView: self.view)
        
        //giving the play button image an action
        let buttonAction1 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imageClicked(gesture:)))
        playButton.addGestureRecognizer(buttonAction1)
        playButton.isUserInteractionEnabled = true
        
        //giving the replay button image an action
        let buttonAction2 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imageClicked(gesture:)))
        replayButton.addGestureRecognizer(buttonAction2)
        replayButton.isUserInteractionEnabled = true
        
        scoreLabel.text = String("0") // setting score to 0 for when game starts
        self.view.bringSubviewToFront(self.scoreLabel)// brings the score to the front of all views
        
        //hiding all the views which are not needed for load screen
        gameOverImage.isHidden = true
        scoreLabel.isHidden = true
        replayButton.isHidden = true
        
        //added to make a cool motion affect of road and trees before game starts - UX related
        roadStart()
        treeStart()
        
        view.bringSubviewToFront(playButton)
    }
    
    @objc func gameStart() {
        
        score = 0
        gameIsPlaying = true
        
        playButton.isHidden = true
        replayButton.isHidden = true
        
        let time = DispatchTime.now()
        
        roadStart()
        treeStart()
        planeStart()
        behaviorFunctions()
        coinStart()
        birdStart()
        
        scoreLabel.isHidden = false
        scoreLabel.text = String("Score: \(score)")
        self.view.bringSubviewToFront(scoreLabel)
        
        itemA = DispatchWorkItem {
            self.hidePlayView()
        }
        
        let w = time + .seconds(20)
        DispatchQueue.main.asyncAfter(deadline: w, execute: itemA)
        
    }
    
    //hides all images used for game play, brings button, score and gameover image to screen
    func hidePlayView() {
        
        itemA.cancel()
        gameIsPlaying = false
        
        planeMoving.isHidden = true
        playButton.isHidden = true
        
        gameOverImage.isHidden = false
        replayButton.isHidden = false
        
        self.view.bringSubviewToFront(gameOverImage)
        self.view.bringSubviewToFront(replayButton)
        self.view.bringSubviewToFront(scoreLabel)
        
        self.view.layer.removeAllAnimations()
    }
    
    @objc func imageClicked(gesture: UIGestureRecognizer) {
        if !gameIsPlaying {
            gameStart()
        }
    }
    
    func planeStart() {
        
        planeMoving = UIImageView()
        planeMoving.frame = CGRect(x: 0, y: self.mainHeight / 2, width: 126, height: 74)
        
        planeMoving.center.x = mainWidth * 0.15
        planeMoving.center.y = mainHeight / 2
        
        var planeArray: [UIImage] = [UIImage(named: "plane1")!]
        
        for i in 2 ... 15 {
            planeArray += [UIImage(named: "plane\(i)")!]
        }
        
        planeMoving.image = UIImage.animatedImage(with: planeArray, duration: 1)
        view.addSubview(planeMoving)
    }
    
    func roadStart(){
        roadMoving = UIImageView()
        roadMoving.frame = CGRect(x: 0, y: 0, width: self.mainWidth, height: self.mainHeight)
        
        var roadArray: [UIImage] = [UIImage(named: "road1")!]
        
        for i in 2 ... 19 {
            roadArray += [UIImage(named: "road\(i)")!]
            
        }
        
        roadMoving.image = UIImage.animatedImage(with: roadArray, duration: 1)
        view.addSubview(roadMoving)
        
    }
    
    func treeStart() {
        
        treeMoving = UIImageView()
        treeMoving.frame = CGRect(x: 0, y: 0, width: self.mainWidth, height: self.mainHeight)
        
        var treeArray: [UIImage] = [UIImage(named: "tree1")!]
        for i in 2 ... 17 {
            treeArray += [UIImage(named: "tree\(i)")!]
            
        }
        
        treeMoving.image = UIImage.animatedImage(with: treeArray, duration: 1)
        view.addSubview(treeMoving)
        
    }
    
    func randomNumber(Min: Int, Max: Int) -> Int {
        
        if Min - Max < 0 {
            return Int(arc4random_uniform(UInt32(Max-Min)) + UInt32(Min))
        }
            
        else {
            return Int(arc4random_uniform(UInt32(Min-Max)) + UInt32(Min))
        }
    }
    
    func behaviorFunctions() {
        
        collisionBehavior = UICollisionBehavior(items: [])
        itemBehavior = UIDynamicItemBehavior(items: [])
        collisionBehavior.collisionMode = UICollisionBehavior.Mode.boundaries
        collisionBehavior.addBoundary(withIdentifier: "plane" as NSCopying, for: UIBezierPath(rect: planeMoving.frame))
        animator.addBehavior(itemBehavior)
        animator.addBehavior(collisionBehavior)
        
        collisionBehavior.action = {
            
            for bird in self.birdMoving {
                if(self.planeMoving.frame.intersects(bird.frame) && bird.tag == 69){
                    self.score = self.score - 500
                    self.scoreLabel.text = String("Score: \(self.score)")
                    
                    //bird and coin are tagged to identify them, setting them to 70 allows for score to stop printing to the label after initial collision - score added/lost once each collision
                    bird.tag = 70
                    bird.removeFromSuperview()
                }
            }
            
            for coin in self.coinMoving {
                if(self.planeMoving.frame.intersects(coin.frame) && coin.tag == 69){
                    self.score = self.score + 200
                    self.scoreLabel.text = String("Score: \(self.score)")
                    
                    coin.tag = 70
                    coin.removeFromSuperview()
                }
            }
        }
    }
    
    func birdStart() {
        
        var birdArray: [UIImage] = [UIImage(named: "bird1")!]
        
        for a in 2 ... 10 {
            birdArray += [UIImage(named: "bird\(a)")!]
        }
        
        let birdAnimated = UIImage.animatedImage(with: birdArray, duration: 1)
        let birdRandom = Int(randomNumber(Min: 2, Max: 6))
        
        for _ in 1 ... birdRandom {
            
            let randomSpeed: Double = Double(randomNumber(Min: 250, Max: 350))
            let birdPosition = CGFloat(Float(randomNumber(Min: 50, Max: Int(Float(self.mainHeight - 100)))))
            let randomTimer = DispatchTime.now() + .seconds(randomNumber(Min: 0, Max: 17))
            DispatchQueue.main.asyncAfter(deadline: randomTimer) {
                
                let birdView = UIImageView(image: birdAnimated)
                birdView.tag = 69//tag set here
                birdView.frame = CGRect(x: self.mainWidth, y: birdPosition, width: 60, height: 60)
                self.view.addSubview(birdView)
                self.view.bringSubviewToFront(birdView)
                self.itemBehavior.addItem(birdView)
                self.itemBehavior.addLinearVelocity(CGPoint(x: -randomSpeed, y: 0), for: birdView)
                self.birdMoving.append(birdView)
                DispatchQueue.main.asyncAfter(deadline: randomTimer + Double(ceil(Float(self.mainWidth) / Float(randomSpeed))) + 2){
                    
                    self.collisionBehavior.removeItem(birdView)
                    self.itemBehavior.removeItem(birdView)
                    birdView.removeFromSuperview()
                    
                }
            }
        }
    }
    
    func coinStart() {
        
        let coinRandom = Int(randomNumber(Min: 2, Max: 6))
        
        for _ in 1 ... coinRandom {
            
            let randomSpeed: Double = Double(randomNumber(Min: 250, Max: 350))
            let coinPosition = CGFloat(Float(randomNumber(Min: 0, Max: Int(Float(self.mainHeight - 50)))))
            let randomTimer = DispatchTime.now() + Double(randomNumber(Min: 0, Max: 17))
            DispatchQueue.main.asyncAfter(deadline: randomTimer) {
                
                let coinView = UIImageView(image: UIImage(named: "coin"))
                coinView.tag = 69
                coinView.frame = CGRect(x: self.mainWidth, y: coinPosition, width: 60, height: 60)
                self.view.addSubview(coinView)
                self.view.bringSubviewToFront(coinView)
                self.itemBehavior.addItem(coinView)
                self.itemBehavior.addLinearVelocity(CGPoint(x: -randomSpeed, y: 0), for: coinView)
                self.coinMoving.append(coinView)
                DispatchQueue.main.asyncAfter(deadline: randomTimer + Double(ceil(Float(self.mainWidth) / Float(randomSpeed))) + 1){
                    
                    self.collisionBehavior.removeItem(coinView)
                    self.itemBehavior.removeItem(coinView)
                    coinView.removeFromSuperview()
                    
                }
            }
        }
    }
    
    var planeDragged: CGPoint?
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        planeDragged = touches.first?.location(in: planeMoving)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if planeMoving == nil {
            return
        }
        
        let currentLocation = touches.first?.location(in: planeMoving)
        let dx = currentLocation!.x - planeDragged!.x
        let dy = currentLocation!.y - planeDragged!.y
        
        planeMoving.center = CGPoint(x: planeMoving.center.x+dx, y: planeMoving.center.y+dy)
        collisionBehavior.removeAllBoundaries()
        collisionBehavior.addBoundary(withIdentifier: "plane" as NSCopying, for: UIBezierPath(rect: planeMoving.frame))
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

