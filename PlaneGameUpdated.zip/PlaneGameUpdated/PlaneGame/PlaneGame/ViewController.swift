//
//  ViewController.swift
//  PlaneGame
//
//  Created by Sam Krol on 10/06/2019.
//  Copyright © 2019 Sam Krol. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollisionBehaviorDelegate {
    
    var animator: UIDynamicAnimator!
    var collisionBehavior: UICollisionBehavior!
    var dynamicItemBehavior: UIDynamicItemBehavior!
    
    var coinMoving: [UIImageView] = []
    var birdMoving: [UIImageView] = []
    
    var score: Int = 0
    
    var roadMoving: UIImageView!
    var planeMoving: UIImageView!
    var treeMoving: UIImageView!
    
    var mainWidth: CGFloat!
    var mainHeight: CGFloat!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainWidth = UIScreen.main.bounds.size.width
        mainHeight = UIScreen.main.bounds.size.height
        
        animator = UIDynamicAnimator(referenceView: self.view)
        
        gameStart()
    }
        
    func randomNumber(Min: Int, Max: Int) -> Int {
        if Min - Max < 0 {
            return Int(arc4random_uniform(UInt32(Max-Min)) + UInt32(Min))
        }
        else {
            return Int(arc4random_uniform(UInt32(Min-Max)) + UInt32(Min))
        }
    }
        
        func behaviorFunctions() {
    
            collisionBehavior = UICollisionBehavior(items: [])
            collisionBehavior.translatesReferenceBoundsIntoBoundary = true
            collisionBehavior.addBoundary(withIdentifier: "plane" as NSCopying, for: UIBezierPath(rect: planeMoving.frame))
            dynamicItemBehavior = UIDynamicItemBehavior(items: [])
            animator.addBehavior(collisionBehavior)
            animator.addBehavior(dynamicItemBehavior)
            
            collisionBehavior.action = {
                for bird in self.birdMoving {
                    if(self.planeMoving.frame.intersects(bird.frame)){
                        self.score = self.score - 200
                        print (self.score)
                    }
                }
            }
            
            collisionBehavior.action = {
                for coin in self.coinMoving {
                    if(self.planeMoving.frame.intersects(coin.frame)){
                        self.score = self.score + 200
                        print (self.score)
                    }
                }
            }
        }
        
        behaviorFunctions()
        gameStart()
        
    }
    
        func gameStart() {
            
        birdStart()
        coinStart()
        
        
        
        //Time limit for each game set to 20 seconds
        let timeLimit = DispatchTime.now() + 20
        DispatchQueue.main.asyncAfter(deadline: timeLimit) {
            for view in self.view.subviews {
                view.removeFromSuperview()
            }
        }
        //image doesnt show after game ends
        let gameFinish = UIImageView(image: UIImage(named: "game_over.jpg"))
        gameFinish.alpha = 0
        DispatchQueue.main.asyncAfter(deadline: timeLimit) {
            UIView.animate(withDuration: 0.3) {
                gameFinish.alpha = 1
            }
        }
        
        //Game replay button - not showing
        let gameReplay = UIButton()
        gameReplay.frame = CGRect(x: self.mainWidth / 2 - 130, y: self.mainHeight / 2 - 50, width: 247, height: 100)
        gameReplay.addTarget(self, action: #selector(self.gameStart), for: .touchUpInside)
        self.view.addSubview(gameReplay)
        
        let scoreDisplay = UILabel()
        scoreDisplay.textColor = UIColor.red
        scoreDisplay.text = "Score: \(self.score)"
        scoreDisplay.frame = CGRect(x: self.mainWidth / 2 - 200, y: self.mainHeight - 400, width: 200, height: 150)
        self.view.addSubview(scoreDisplay)
        
        }

        func updateScoreDisplay(seconds: Int) {
                scoreDisplay.text = "\(1000 * seconds)"
        }
    
    func coinStart() {
        let coinRandom = Int(randomNumber(Min: 2, Max: 6))
        for _ in 1 ... coinRandom {
            let randomSpeed: Double = Double(randomNumber(Min: 150, Max: 350))
            let coinPosition = CGFloat(Float(randomNumber(Min: 0, Max: Int(Float(self.mainHeight - 50)))))
            let randomTimer = DispatchTime.now() + Double(randomNumber(Min: 0, Max: 10))
            DispatchQueue.main.asyncAfter(deadline: randomTimer) {
                let coinView = UIImageView(image: UIImage(named: "coin"))
                coinView.frame = CGRect(x: self.mainWidth, y: coinPosition, width: 60, height: 60)
                self.view.addSubview(coinView)
                self.view.bringSubviewToFront(coinView)
                self.dynamicItemBehavior.addItem(coinView)
                self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -randomSpeed, y: 0), for: coinView)
                self.coinMoving.append(coinView)
                DispatchQueue.main.asyncAfter(deadline: randomTimer + Double(ceil(Float(self.mainWidth) / Float(randomSpeed))) + 1){
                    self.collisionBehavior.removeItem(coinView)
                    self.dynamicItemBehavior.removeItem(coinView)
                    coinView.removeFromSuperview()
                }
            }
        }
    }
    
    func birdStart() {
        var imageArrayBird: [UIImage] = [UIImage(named: "bird1")!]
        for a in 2 ... 10 {
            imageArrayBird += [UIImage(named: "bird\(a)")!]
        }
        let birdAnimated = UIImage.animatedImage(with: imageArrayBird, duration: 1)
        let birdRandom = Int(randomNumber(Min: 2, Max: 6))
        for _ in 1 ... birdRandom {
            let randomSpeed: Double = Double(randomNumber(Min: 150, Max: 350))
            let birdPosition = CGFloat(Float(randomNumber(Min: 0, Max: Int(Float(self.mainHeight - 50)))))
            let randomTimer = DispatchTime.now() + Double(randomNumber(Min: 0, Max: 10))
            DispatchQueue.main.asyncAfter(deadline: randomTimer) {
                let birdView = UIImageView(image: birdAnimated)
                birdView.frame = CGRect(x: self.mainWidth, y: birdPosition, width: 60, height: 60)
                self.view.addSubview(birdView)
                self.view.bringSubviewToFront(birdView)
                self.dynamicItemBehavior.addItem(birdView)
                self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -randomSpeed, y: 0), for: birdView)
                self.birdMoving.append(birdView)
                DispatchQueue.main.asyncAfter(deadline: randomTimer + Double(ceil(Float(self.mainWidth) / Float(randomSpeed))) + 2){
                    self.collisionBehavior.removeItem(birdView)
                    self.dynamicItemBehavior.removeItem(birdView)
                    birdView.removeFromSuperview()
                }
            }
        }
        
        func planeSetup() {
            planeImage = UIImageView()
            planeImage.frame = CGRect(x: 0, y: self.screenHeight / 2, width: 126, height: 74)
            
            var planeImageArray: [UIImage] = [UIImage(named: "plane1")!]
            for i in 2 ... 15 {
                planeImageArray += [UIImage(named: "plane\(i)")!]
            }
            planeImage.image = UIImage.animatedImage(with: planeImageArray, duration: 1)
            
            view.addSubview(planeImage)
        }
    
        

    
    /*   func scoreTotal(){
     for plane1 in self.plane1 {
     score += 30
     scoreDisplay.text = "\(score)"
     }*/
    
    @objc func gameRestart(sender: UIButton!) {
        for view in self.view.subviews {
            view.removeFromSuperview()
        }
        gameStart()
    }
    
    /*override func viewDidAppear(_ animated: Bool) {
     super.viewDidAppear(animated)
     
     bird1 = UIImageView.init(frame: CGRect.init(x: 100, y: 100, width: 100, height: 100));
     plane1 = UIImageView.init(frame: CGRect.init(x: 100, y: 150, width: 100, height: 100))
     bird1.backgroundColor = .red
     plane1.backgroundColor = .yellow
     self.view.addSubview(bird1)
     self.view.addSubview(plane1)
     behaviorFunctions()
     }*/
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // I was planning on adding another view, allowing the user to press "play game" but decided I had no time
    //@IBAction func playGame() {
    
    // let alert = UIAlertController(title: "Play Game!", message: nil, preferredStyle: .alert)
    
    // let action = UIAlertAction(title: "OK", style: .default, handler: nil)
    
    //alert.addAction(action)
    
    //present(alert, animated: true, completion: nil)
    //  }
    
    
    
    
}
