//
//  ViewController.swift
//  Sam_PlaneGame
//
//  Created by user147336 on 11/21/18.
//  Copyright © 2018 Sam STUDENT ID: 15050741. All rights reserved.
//

import UIKit


class ViewController: UIViewController, UICollisionBehaviorDelegate {

    var score: Int = 0
    
    @IBOutlet weak var replayButton: UIImageView!
    
    @IBOutlet weak var gameOverImage: UIImageView!
    
    @IBOutlet weak var scoreLabel: UILabel!

    var animator: UIDynamicAnimator!

    var collisionBehavior: UICollisionBehavior!
    var dynamicItemBehavior: UIDynamicItemBehavior!
    
    var coinMoving: [UIImageView] = []
    var birdMoving: [UIImageView] = []

    var planeMoving: UIImageView!
    var roadMoving: UIImageView!
    var treeMoving: UIImageView!
    
    var planeArray: [UIImage] = [UIImage(named: "plane1")!]
    
    let mainWidth = UIScreen.main.bounds.size.width
    let mainHeight = UIScreen.main.bounds.size.height
    
    var gameFinish: UIImageView!
    var gameReplay = UIButton()
    
    var workItem = DispatchWorkItem {}
    
    override func viewDidLoad() {

        super.viewDidLoad()
        
        animator = UIDynamicAnimator(referenceView: self.view)
        
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imageTapped(gesture:)))
        
        replayButton.addGestureRecognizer(tapGesture1)
        replayButton.isUserInteractionEnabled = true
        
        //playGame()
        
        //scoreLabel.text = String("0")
       // self.view.bringSubviewToFront(self.scoreLabel)
        gameStart()
        
    }
    
    @objc func gameStart() {
        let time = DispatchTime.now()
        
        replayButton.isHidden = true
        gameOverImage.isHidden = true
        
        roadStart()
        treeStart()
        planeStart()
        behaviorFunctions()
        coinStart()
        birdStart()
        
        scoreLabel.text = String("Score: \(score)")
        self.view.bringSubviewToFront(scoreLabel)
        
        workItem = DispatchWorkItem {
            self.hideViews()
        }
        let when = time + .seconds(20)
        DispatchQueue.main.asyncAfter(deadline: when, execute: workItem)
        
//        score = 0
//        //playGame()
//        //updateUI()
//        roadStart()
//        treeStart()
//        planeStart()
//        behaviorFunctions()
//        coinStart()
//        birdStart()
//
//
//
//        //Time limit for each game set to 20 seconds
//        let timeLimit = DispatchTime.now() + 20
//        DispatchQueue.main.asyncAfter(deadline: timeLimit) {
//            for view in self.view.subviews {
//                view.removeFromSuperview()
//                self.gameRestart()
//
//            }
//            self.birdMoving = []
//            self.animator.removeAllBehaviors()
//
//            self.gameFinished()
//            self.gameReplayed()
//
//            let scoreDisplay = UILabel()
//            scoreDisplay.textColor = UIColor.red
//            scoreDisplay.text = "Score: \(self.score)"
//            scoreDisplay.frame = CGRect(x: self.mainWidth / 2 - 200, y: self.mainHeight - 400, width: 200, height: 150)
//            self.view.addSubview(scoreDisplay)
//
//
//
//        }
        
        //unHideViews()
        
    }
    
    func behaviorFunctions() {
        
        collisionBehavior = UICollisionBehavior(items: [])
        dynamicItemBehavior = UIDynamicItemBehavior(items: [])
        collisionBehavior.collisionMode = UICollisionBehavior.Mode.boundaries
        collisionBehavior.addBoundary(withIdentifier: "plane" as NSCopying, for: UIBezierPath(rect: planeMoving.frame))
          animator.addBehavior(dynamicItemBehavior)
        animator.addBehavior(collisionBehavior)
        
        collisionBehavior.action = {
            for bird in self.birdMoving {
                if(self.planeMoving.frame.intersects(bird.frame)){
                    self.score = self.score - 100
                    bird.isHidden = true
                    self.planeMoving.image = UIImage(named: "explosion.png")
                    self.hideViews()
                    
                    self.gameFinished()

                }
      
            for coin in self.coinMoving {
                if(self.planeMoving.frame.intersects(coin.frame)){
                    self.score = self.score + 200
                    self.scoreLabel.text = String("Score: \(self.score)")
                    coin.isHidden = true
        
                    }
                }
            }
        }
        
    }
    
    @objc func imageTapped(gesture: UIGestureRecognizer) {
        gameStart()
    }
//
//    func gameReplayed() {
//
//        gameReplay = UIButton()
//        gameReplay.frame = CGRect(x: self.mainWidth / 2 - 130, y: self.mainHeight / 2 - 50, width: 247, height: 100)
//        gameReplay.addTarget(self, action: #selector(self.gameStart), for: .touchUpInside)
//        self.view.addSubview(gameReplay)
//        self.view.bringSubviewToFront(gameReplay)
//
//    }
    
    func gameFinished() {
        
        self.view.layer.removeAllAnimations()
        
        gameFinish = UIImageView(image: UIImage(named: "game_over"))
        gameFinish.frame = CGRect(x: 0, y: 0, width: self.mainWidth, height: self.mainHeight)
        self.view.addSubview(gameFinish)
        self.view.bringSubviewToFront(self.replayButton)

        
    }
    
    func randomNumber(Min: Int, Max: Int) -> Int {
        
        if Min - Max < 0 {
            return Int(arc4random_uniform(UInt32(Max-Min)) + UInt32(Min))
            
        }
            
        else {
            return Int(arc4random_uniform(UInt32(Min-Max)) + UInt32(Min))
            
        }
    }
    
    func planeStart() {
        
        planeMoving = UIImageView()
        planeMoving.frame = CGRect(x: 0, y: self.mainHeight / 2, width: 126, height: 74)
        
        planeMoving.center.x = mainWidth * 0.15
        planeMoving.center.y = mainHeight / 2
        
        for i in 2 ... 15 {
            planeArray += [UIImage(named: "plane\(i)")!]
            
        }
        
        planeMoving.image = UIImage.animatedImage(with: planeArray, duration: 1)
        view.addSubview(planeMoving)
        
    }
    
    func hideGameOver() {
        
    }
    
    func hideViews() {
        
        workItem.cancel()
        
        planeMoving.isHidden = true
        treeMoving.isHidden = true
        roadMoving.isHidden = true
        
        self.view.layer.removeAllAnimations()
        
        gameOverImage.isHidden = false
        replayButton.isHidden = false
        
        score = 0
        
    }
    
    func treeStart() {
        
        treeMoving = UIImageView()
        treeMoving.frame = CGRect(x: 0, y: 0, width: self.mainWidth, height: self.mainHeight)
        
        var treeArray: [UIImage] = [UIImage(named: "tree1")!]
        for i in 2 ... 17 {
            treeArray += [UIImage(named: "tree\(i)")!]
            
        }
        
        treeMoving.image = UIImage.animatedImage(with: treeArray, duration: 1)
        view.addSubview(treeMoving)
        
    }

    
    func roadStart(){
        
        roadMoving = UIImageView()
        roadMoving.frame = CGRect(x: 0, y: 0, width: self.mainWidth, height: self.mainHeight)
        
        var roadArray: [UIImage] = [UIImage(named: "road1")!]
        
        for i in 2 ... 19 {
            roadArray += [UIImage(named: "road\(i)")!]
            
        }
        
        roadMoving.image = UIImage.animatedImage(with: roadArray, duration: 1)
        view.addSubview(roadMoving)
        
    }

  
    func coinStart() {
        
        let coinRandom = Int(randomNumber(Min: 2, Max: 6))
        
        for _ in 1 ... coinRandom {
            
            let randomSpeed: Double = Double(randomNumber(Min: 250, Max: 350))
            let coinPosition = CGFloat(Float(randomNumber(Min: 0, Max: Int(Float(self.mainHeight - 50)))))
            let randomTimer = DispatchTime.now() + Double(randomNumber(Min: 0, Max: 10))
            DispatchQueue.main.asyncAfter(deadline: randomTimer) {
                
                let coinView = UIImageView(image: UIImage(named: "coin"))
                coinView.frame = CGRect(x: self.mainWidth, y: coinPosition, width: 60, height: 60)
                self.view.addSubview(coinView)
                self.view.bringSubviewToFront(coinView)
                self.dynamicItemBehavior.addItem(coinView)
                self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -randomSpeed, y: 0), for: coinView)
                self.coinMoving.append(coinView)
                DispatchQueue.main.asyncAfter(deadline: randomTimer + Double(ceil(Float(self.mainWidth) / Float(randomSpeed))) + 1){
                    
                    self.collisionBehavior.removeItem(coinView)
                    self.dynamicItemBehavior.removeItem(coinView)
                    coinView.removeFromSuperview()
                    
                }
            }
        }
    }
    
    func birdStart() {
        
        var birdArray: [UIImage] = [UIImage(named: "bird1")!]
        
        for a in 2 ... 10 {
            
            birdArray += [UIImage(named: "bird\(a)")!]
            
        }
        
        let birdAnimated = UIImage.animatedImage(with: birdArray, duration: 1)
        let birdRandom = Int(randomNumber(Min: 2, Max: 6))
       
        for _ in 1 ... birdRandom {
            
        let randomSpeed: Double = Double(randomNumber(Min: 250, Max: 350))
        let birdPosition = CGFloat(Float(randomNumber(Min: 50, Max: Int(Float(self.mainHeight - 100)))))
        let randomTimer = DispatchTime.now() + Double(randomNumber(Min: 0, Max: 5))
        DispatchQueue.main.asyncAfter(deadline: randomTimer) {
            
            let birdView = UIImageView(image: birdAnimated)
            birdView.frame = CGRect(x: self.mainWidth, y: birdPosition, width: 60, height: 60)
            self.view.addSubview(birdView)
            self.view.bringSubviewToFront(birdView)
            self.dynamicItemBehavior.addItem(birdView)
            self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: -randomSpeed, y: 0), for: birdView)
            self.birdMoving.append(birdView)
            DispatchQueue.main.asyncAfter(deadline: randomTimer + Double(ceil(Float(self.mainWidth) / Float(randomSpeed))) + 2){
                
                self.collisionBehavior.removeItem(birdView)
                self.dynamicItemBehavior.removeItem(birdView)
                birdView.removeFromSuperview()
                
                }
            }
        }
    }

    
    func gameRestart() {
        
        gameStart()
        
        /*let endGameAlert = UIAlertController(title: "Awesome", message: "You finsihed the round! Do you wish play again?", preferredStyle: .alert)
        let restartAction = UIAlertAction(title: "Restart", style: .default) { (UIAlertAction) in
            self.startOver()
        }
        
        endGameAlert.addAction(restartAction)
        
        present(endGameAlert, animated: true, completion: nil)*/
        
    }
    
    func startOver() {
        
        gameStart()
        
    }
    
    /*func updateUI() {
        
        scoreLabel.text = "Score: \(score)"
        
        
    }*/
    
    var planeDragged: CGPoint?
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        planeDragged = touches.first?.location(in: planeMoving)
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if planeMoving == nil {
            return
            
        }
        
        let currentLocation = touches.first?.location(in: planeMoving)
        let dx = currentLocation!.x - planeDragged!.x
        let dy = currentLocation!.y - planeDragged!.y
        
        planeMoving.center = CGPoint(x: planeMoving.center.x+dx, y: planeMoving.center.y+dy)
        collisionBehavior.removeAllBoundaries()
        collisionBehavior.addBoundary(withIdentifier: "plane" as NSCopying, for: UIBezierPath(rect: planeMoving.frame))
        
    }
    
    

    override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    }
    
    

    



}

